------------------------------------------------------------
-- Maintenance classification — Build 49.39
-- Module: autorun/project_overflow/ui/cheats.lua
-- Role: ImGui or native-overlay presentation and diagnostics.
-- Status: active UI.
--
-- Compatibility policy:
--   Existing functions, hooks, module paths, and diagnostics are
--   intentionally retained in this maintenance pass.
--   `DEPRECATED` marks a supported legacy path, not removed code.
------------------------------------------------------------

------------------------------------------------------------
-- Project: Overflow — Consolidated Cheat Controls
--
-- All direct HP, Max HP, XP and profile mutation tools live here.
-- Gameplay functionality remains in the owning systems.
------------------------------------------------------------

local rpg = require("project_overflow.systems.player.rpg")
local stat_application =
    require("project_overflow.systems.player.stat_application")

local cheats = {
    xp_amount = 100,
    set_xp = 0,
    recovery_slot = 0
}

local function value(label, content)
    imgui.text(label .. " : " .. tostring(content))
end

local function button_row(a, b, c)
    local pressed = nil
    if imgui.button(a) then pressed = a end
    if b ~= nil then
        imgui.same_line()
        if imgui.button(b) then pressed = b end
    end
    if c ~= nil then
        imgui.same_line()
        if imgui.button(c) then pressed = c end
    end
    return pressed
end

local function draw_hp(ctx, hp)
    if not imgui.tree_node("HP Controls") then return end
    local changed
    changed, ctx.ui.hp_amount =
        imgui.drag_int("HP Amount", ctx.ui.hp_amount, 1, 1, 5000)
    ctx.ui.hp_amount = ctx.clamp(ctx.ui.hp_amount, 1, 5000)
    local pressed = button_row("Heal", "Damage", "Full Heal")
    if pressed == "Heal" then hp.heal(ctx, ctx.ui.hp_amount) end
    if pressed == "Damage" then hp.damage(ctx, ctx.ui.hp_amount) end
    if pressed == "Full Heal" then hp.full_heal(ctx) end
    changed, ctx.ui.set_current_hp = imgui.drag_int(
        "Set Current HP", ctx.ui.set_current_hp, 1, 1, ctx.active_total_cap())
    if imgui.button("Apply Current HP") then
        hp.set_current(ctx, ctx.ui.set_current_hp)
    end
    imgui.tree_pop()
end

local function draw_max_hp(ctx, hp)
    if not imgui.tree_node("Max HP Controls") then return end
    local changed
    changed, ctx.ui.max_hp_amount =
        imgui.drag_int("Max HP Amount", ctx.ui.max_hp_amount, 1, 1, 5000)
    ctx.ui.max_hp_amount = ctx.clamp(ctx.ui.max_hp_amount, 1, 5000)
    local pressed = button_row("Add Max HP", "Remove Max HP")
    if pressed == "Add Max HP" then hp.add_max(ctx, ctx.ui.max_hp_amount) end
    if pressed == "Remove Max HP" then hp.add_max(ctx, -ctx.ui.max_hp_amount) end
    changed, ctx.ui.set_max_hp = imgui.drag_int(
        "Set Max HP", ctx.ui.set_max_hp, 1,
        ctx.state.min_custom_max_hp, ctx.active_total_cap())
    if imgui.button("Apply Max HP") then hp.set_max(ctx, ctx.ui.set_max_hp) end
    local reset = button_row("Reset Default", "Reset Vanilla Cap")
    if reset == "Reset Default" then hp.reset_default(ctx) end
    if reset == "Reset Vanilla Cap" then hp.reset_vanilla(ctx) end
    imgui.tree_pop()
end

local function draw_xp()
    if not imgui.tree_node("XP Controls") then return end
    local changed
    changed, cheats.xp_amount = imgui.drag_int(
        "XP Amount", cheats.xp_amount, 1, 1, 1000000)
    if imgui.button("Add XP") then rpg.add_experience(cheats.xp_amount) end
    imgui.same_line()
    if imgui.button("Remove XP") then rpg.remove_experience(cheats.xp_amount) end
    changed, cheats.set_xp = imgui.drag_int(
        "Set Current XP", cheats.set_xp, 1, 0, 1000000)
    if imgui.button("Set XP") then rpg.set_experience(cheats.set_xp) end
    imgui.same_line()
    if imgui.button("Reset Current XP") then
        rpg.set_experience(0)
        cheats.set_xp = 0
    end
    if imgui.button("Add XP Required for Next Level") then
        rpg.add_experience(rpg.required_xp())
    end
    imgui.same_line()
    if imgui.button("Force Level Up") then rpg.force_level() end
    value("Current XP", rpg.profile().experience)
    value("Next Level Requirement", rpg.required_xp())
    value("Last Levels Gained", rpg.last_levels_gained)
    imgui.tree_pop()
end

local function draw_profile_tools(ctx, hp)
    if not imgui.tree_node("Emergency RPG Profile Tools") then return end
    imgui.text("Cheat/recovery tools only. Normal progression saves with RE4.")
    local profile = rpg.profile()
    if imgui.button("Add Attribute Point") then
        profile.attribute_points = profile.attribute_points + 1
        rpg.last_message = "Added one attribute point."
    end
    -- Native game-save synchronization is the only automatic persistence
    -- path. Keep the old change-autosave capability disabled.
    rpg.autosave_on_change = false
    if imgui.button("Save RPG Profile") then rpg.save() end
    imgui.same_line()
    if imgui.button("Load RPG Profile") then rpg.load() end
    if imgui.button("Reset RPG Profile") then
        stat_application.remove_vitality(ctx, hp)
        rpg.reset()
    end
    if imgui.button("Reset Vitality HP Tracking") then
        stat_application.reset_tracking()
    end
    if rpg.active_save_slot() == nil then
        imgui.separator()
        imgui.text(
            "One-time recovery: choose the RE4 save currently loaded."
        )
        imgui.text(
            "Slot 0 = Autosave; slots 1-20 = Manual saves."
        )

        local changed

        changed,
        cheats.recovery_slot =
            imgui.drag_int(
                "Recovery Save Slot",
                cheats.recovery_slot,
                1,
                0,
                20
            )

        cheats.recovery_slot =
            math.max(
                0,
                math.min(
                    20,
                    cheats.recovery_slot
                )
            )

        local recovery_key =
            cheats.recovery_slot == 0
            and "autosave"
            or cheats.recovery_slot

        value(
            "Recovery Target",
            cheats.recovery_slot == 0
            and "Autosave"
            or string.format(
                "Manual Slot %02d",
                cheats.recovery_slot
            )
        )

        if imgui.button("Bind and Load This RPG Slot") then
            if
                rpg.select_save_slot(
                    recovery_key,
                    true
                )
            then
                stat_application.reset_tracking()
            end
        end
    end
    value("Save Path", rpg.save_path())
    imgui.tree_pop()
end

function cheats.draw(ctx, hp)
    -- This is visibility only. Runtime RPG systems and native hooks are
    -- initialized by project_overflow.lua and never depend on this tree.
    if not imgui.tree_node("Cheats") then return end
    draw_hp(ctx, hp)
    draw_max_hp(ctx, hp)
    draw_xp()
    draw_profile_tools(ctx, hp)
    imgui.tree_pop()
end

return cheats
